package application;
	

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;

/**
 * This class contains the code that sets the GUI by defining important aspects of the primary stage. 
 * Additionally, this class also contains the main method which is where the compiler begins when running the code.
 * @author Tejas Gill, Liam Ingram
 * @version March 31, 2024
 */
public class Main extends Application {
	
	/**
	 * This method below sets the primary stage for the GUI that will be used in the project. 
	 * It also links important features of the primary stages to the fxml in the view package as well
	 * as the styling sheet for the scene in the view application. 
	 */
	@Override
	public void start(Stage primaryStage) {
		try {
			BorderPane root = (BorderPane)FXMLLoader.load(getClass().getResource("../view/ToyStoreScene.fxml"));
			Scene scene = new Scene(root,1000,600);
			scene.getStylesheets().add(getClass().getResource("../view/application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("TOY STORE COMPANY");
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This is the main method of the application. Essentially, this is the start point of the 
	 * application and thereby it is the component that begins by launching the GUI.
	 * @param args	String array that has to be passed to the main method of the program. 
	 */
	public static void main(String[] args) {
		launch(args);
	}
}
