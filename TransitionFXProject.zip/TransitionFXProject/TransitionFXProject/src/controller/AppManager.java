package controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import exceptions.InappropriateMinimumException;
import exceptions.NegativePriceException;

import java.util.ArrayList;

import model.Animal;
import model.Figure;
import model.Game;
import model.Puzzle;
import model.Toy;

/**
 * This class contains and completes all processing of data and user input
 * received through the toy store.
 * 
 * @author Tejas Gill, Liam Ingram
 * @version March 31, 2024
 */
public class AppManager {

	private final String FILE_PATH = "res/toys.txt"; // File path for the database of all inventory toys
	ArrayList<Toy> inventory; // Declare ArrayList of Toys. All toys from the database will be loaded into
								// this single ArrayList.
	ArrayList<Toy> results; // Declare ArrayList used to find certain toys.
	Scanner fileReader; // Declare scanner

	String serial; // Holds the serial number for an object
	String name; // Holds the name of the toy
	String brand; // Holds the brand name of the toy
	double price; // Holds the price of the toy
	int stock; // Holds the available count for stock available for the item
	int minAge; // Holds the minimum appropriate age to use the toy
	int minPlayer; // Holds the minimum number of players required to play the game
	int maxPlayer; // Holds the maximum number of players that can play the game
	char type; // Holds the classification type of the toy
	Toy t; // Declare a toy object
	boolean flag; // Boolean flag used to run toy store application
	int option; // Holds the user's choice for menu options
	String priceRange; // Holds the price range used for gift suggestions from the user
	double minPrice; // Holds the minimum price based on the price range for the toy
	double maxPrice; // Holds the maximum price based on the prince range for the toy
	String material; // Holds the material that the toy is made of.
	char size; // Holds the size of the toy
	String[] designers; // Holds all the designers that created a toy.
	int index; // Holds the index used for certain searches.
	String input; // Holds user input that is stored as string for validation purposes.
	int finalDecision; // Holds the user's decision in cases of deciding to purchase items.
	boolean flag2; // Holds flag for the sub menu.

	/**
	 * Constructor for the AppManager class. Functions to initialize inventory
	 * arrayList.
	 */
	public AppManager() {
		inventory = new ArrayList<Toy>(); // Initialize an ArrayList to hold all toys from the database.
	}

	/**
	 * This method loads toy data from the database into a single arrayList, known
	 * as inventory.
	 * @return The inventory arrayList loaded with all the data from the database for toys is returned by the function.
	 */
	public ArrayList<Toy> loadData() {
		File db = new File(FILE_PATH);	//Create File Object for the Database file
		String currentLine;				//Used to hold each line of the file processed
		String[] splittedLine;			//Is a arrayList of the specific spliting of the data
		
		char type;						
		char[] figureTypes = { 'A', 'D', 'H' };
		Toy toy = null;		// Initialize the toy object
		
		//Check to see if database exists
		if (db.exists()) {
			try {
				fileReader = new Scanner(db);	//Initialize scanner
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			
			//Run while loop while the file still have information in the next line.
			while (fileReader.hasNextLine()) {

				currentLine = fileReader.nextLine();
				splittedLine = currentLine.split(";");

				// Check length of splittedLine to know the type of toy object
				if (splittedLine.length == 7) {

					boolean fig = false;
					type = Character.toUpperCase(splittedLine[6].charAt(0));

					for (char t : figureTypes) {
						if (t == type) {
							toy = makeFigure(splittedLine);
							fig = true;
							break;
						}

						if (fig == false)
							toy = makePuzzle(splittedLine);

					}

				}

				else {
					// Check to see the length of the 8th entry
					if (splittedLine[7].length() > 1)
						toy = makeGame(splittedLine);
					// If the length of the 8th element in the array is greater than one it is an
					// Animal Toy.
					else
						toy = makeAnimal(splittedLine);
				}
				inventory.add(toy); // Add toy to the inventory
			}
			fileReader.close(); // Close FileReader
		}

		return inventory;
	}

	

	/**
	 * This function creates an toy object by calling the figure constructor. The
	 * information required to call the figure constructor is provided within the
	 * string array passed to the method.
	 * 
	 * @param splittedLine String array holding all of the information that will be
	 *                     passed to the constructor to create a toy object.
	 * @return The resulting toy that is created is returned by the method.
	 */
	private Toy makeFigure(String[] splittedLine) {
		Toy t = new Figure(splittedLine[0], splittedLine[1], splittedLine[2], Double.parseDouble(splittedLine[3]),
				Integer.parseInt(splittedLine[4]), Integer.parseInt(splittedLine[5]),
				splittedLine[6].toUpperCase().charAt(0));
		return t;

	}

	/**
	 * This function creates an toy object by calling the Puzzle constructor. The
	 * information required to call the puzzle constructor is provided within the
	 * string array passed to the method.
	 * 
	 * @param splittedLine String array holding all of the information that will be
	 *                     passed to the constructor to create a toy object.
	 * @return The resulting toy that is created is returned by the method.
	 */
	private Toy makePuzzle(String[] splittedLine) {
		Toy t = new Puzzle(splittedLine[0], splittedLine[1], splittedLine[2], Double.parseDouble(splittedLine[3]),
				Integer.parseInt(splittedLine[4]), Integer.parseInt(splittedLine[5]),
				splittedLine[6].toUpperCase().charAt(0));
		return t;
	}

	/**
	 * This function creates an toy object by calling the game constructor. The
	 * information required to call the game constructor is provided within the
	 * string array passed to the method.
	 * 
	 * @param splittedLine String array holding all of the information that will be
	 *                     passed to the constructor to create a toy object.
	 * @return The resulting toy that is created is returned by the method.
	 */
	private Toy makeGame(String[] splittedLine) {
		Toy t = new Game(splittedLine[0], splittedLine[1], splittedLine[2], Double.parseDouble(splittedLine[3]),
				Integer.parseInt(splittedLine[4]), Integer.parseInt(splittedLine[5]), splittedLine[6],
				splittedLine[7].split(","));
		return t;
	}

	/**
	 * This function creates an toy object by calling the animal constructor. The
	 * information required to call the animal constructor is provided within the
	 * string array passed to the method.
	 * 
	 * @param splittedLine String array holding all of the information that will be
	 *                     passed to the constructor to create a toy object.
	 * @return The resulting toy that is created is returned by the method.
	 */
	private Toy makeAnimal(String[] splittedLine) {
		Toy t = new Animal(splittedLine[0], splittedLine[1], splittedLine[2], Double.parseDouble(splittedLine[3]),
				Integer.parseInt(splittedLine[4]), Integer.parseInt(splittedLine[5]), splittedLine[6],
				splittedLine[7].toUpperCase().charAt(0));
		return t;
	}

	
	 /**
	 * This method returns an arrayList of toys that have the serial number
	 * suggested by the user.
	 * 
	 * @param input This is the user's provided serial number.
	 * @return An arrayList containing the toys with matching serial number is
	 *         returned.
	 */
	public ArrayList<Toy> findSerialNumber(String input) {
		ArrayList<Toy> results = new ArrayList<Toy>();

		for (Toy t : inventory) {
			if (t.getSerial().contains(input)) {
				results.add(t);
			}
		}
		this.results = results;
		return results;
	}

	/**
	 * This method returns an arrayList of toys that correspond to the type of toy
	 * the user suggested.
	 * 
	 * @param input This string corresponds to the type of toy the user suggested.
	 * @return An arrayList of toys that match the type indicated by the user is
	 *         returned.
	 */
	public ArrayList<Toy> findToyType(String input) {
		ArrayList<Toy> results = new ArrayList<Toy>();

		for (Toy t : inventory) {
			if (t.category().equalsIgnoreCase(input)) {
				results.add(t);
			}
		}
		this.results = results;
		return results;
	}

	/**
	 * This method returns an arrayList of toys that contains the name suggested by
	 * the user.
	 * 
	 * @param input This string corresponds to the name suggested by the user for
	 *              the search.
	 * @return An arrayList of toys that match the type indicated by the user is
	 *         returned.
	 */
	public ArrayList<Toy> findToyName(String input) {
		ArrayList<Toy> results = new ArrayList<Toy>();

		for (Toy t : inventory) {
			if (t.getName().toUpperCase().contains(input.toUpperCase())) {
				results.add(t);
			}
		}
		this.results = results;
		return results;
	}

	/**
	 * This method allows the user to make a purchase of an item in the inventory.
	 * If the stock is not 0, the purchase is processed and the stock decreases by 1.
	 * 
	 * @param finalDecision This integer corresponds to the toy on the displayed
	 *                      list that the user wants to purchase.
	 */
	public ArrayList<Toy> purchase(int finalDecision) {

		// If the stock of the item is 0, purchase cannot be made.
		if (results.get(finalDecision).getStock() == 0) {
		}
		// The item is purchased and modified within the inventory ArrayList.
		else {
			String serialNumber = results.get(finalDecision).getSerial();
			int currentStock = results.get(finalDecision).getStock();

			for (Toy t : inventory) {
				if (t.getSerial().equals(serialNumber)) {
					t.setStock(currentStock - 1);
				}
			}
		}
		return inventory;
	}

	/**
	 * This method validates the serial number that is passed to the method.
	 * 
	 * @param sn This is a string corresponding to the serial number that will be
	 *           validated.
	 * @return A String is returned corresponding to the error with the serial number. If there are not errors, a null string is returned. 
	 */
	public String validateSerialNumber(String sn) {

		String message = null;

		// Check to make sure there are 10 characters
		if (sn.length() != 10) {
			message = "The serial number MUST be 10 digits. Please try again.";
		}

		else {
			// Check to make sure all characters are digits
			for (int i = 0; i < 10; i++) {
				if (!Character.isDigit(sn.charAt(i))) {
					message = "\nThe " + (i + 1) + "th digit of the serial number is not a digit. Please try again.";
				}
			}
			// Check to make sure serial number is unique
			if (findSerialNumber(sn).size() != 0) {
				message = "A toy with this serial number already exists. Please try again.";
			}
		}

		return message;
	}

	/**
	 * This method takes a serial number passed to the method and removed the corresponding toy from the inventory. 
	 * It then returns the modified inventory arrayList of toys. 
	 * 	 
	 * @param serial This is the serial number provided by the user for the toy they would like to remove.
	 * @return This is the modified arrayList after a toy has been removed. 
	 */
	public ArrayList<Toy> removeToy(String serial) {
				
		if(findSerialNumber(serial).size()!=0) {
			String serialNumber = results.get(0).getSerial();
				
			for(Toy t: inventory) {
				if (t.getSerial().equals(serialNumber)) {
					index = inventory.indexOf(t);
					break;
				}
			}
			inventory.remove(index);
		}	
		return inventory;
	}
	
	/**
	 * This method returns an arrayList that is compiled based on the information provided by the user
	 * for a gift suggestion. 
	 * @param choice This int corresponds to the type of information the user wants to use in their suggestion.
	 * @param minAge This is the age for which the user would like a toy to be selected.
	 * @param minPrice This is the minimum price the user is willing to pay.
	 * @param maxPrice This is the maximum price the user is willing to pay.
	 * @param type	This is the toy type the user would like to be considered in their gift suggestion.
	 * @return The arrayList holding all the toys that match the selection information by the user is returned. 
	 */
	public ArrayList<Toy> findAllToys(int choice, int minAge, Double minPrice, Double maxPrice, char type) {
		ArrayList<Toy> results = new ArrayList<Toy>();
		
		// Switches with advanced for loop to acquire all toys from inventory using the information provided by user.
		switch (choice) {
		case 1:
			for (Toy t: inventory) {
				if(t.getMinAge()==minAge) {
					results.add(t);
				}
			}
			break;
		case 2:
			for (Toy t: inventory) {
				if(t.category().charAt(0)==type) {
					results.add(t);
				}
			}
			break;
		case 3:
			for (Toy t: inventory) {
				if( t.getPrice()>=minPrice && t.getPrice()<=maxPrice ) {
					results.add(t);
				}
			}
			break;
		case 4:
			for (Toy t: inventory) {
				if(t.getMinAge()==minAge && t.category().charAt(0)==type) {
					results.add(t);
				}
			}
			break;
		case 5:
			for (Toy t: inventory) {
				if(t.getMinAge()==minAge && t.getPrice()>=minPrice && t.getPrice()<=maxPrice) {
					results.add(t);
				}
			}
			break;
		case 6:
			for (Toy t: inventory) {
				if(t.getPrice()>=minPrice && t.getPrice()<=maxPrice && t.category().charAt(0)==type) {
					results.add(t);
				}
			}
			break;
		case 7:
			for (Toy t: inventory) {
				if(t.getMinAge()==minAge && t.getPrice()>=minPrice && t.getPrice()<=maxPrice && t.category().charAt(0)==type) {
					results.add(t);
				}
			}
			break;
		default: 
			break;
		}
		
		this.results=results;
		return results;
	}
	
}
