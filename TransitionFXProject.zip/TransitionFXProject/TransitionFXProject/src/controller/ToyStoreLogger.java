package controller;

import java.io.IOException;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

/**
 * This class contains all functions pertaining to the logger of the toy store company application.
 * @author Tejas Gill, Liam Ingram
 * @version March 31, 2024
 */
public class ToyStoreLogger {

	//Creation of the logger object for the application
	private final static Logger LOGR = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	
	/**
	 * Constructor for the class.
	 * It calls the setConsoleLog function which essentially changes the level of logs that are displayed on the 
	 * console and also provides the necessary handlers to write the logs to a file. 
	 */
	public ToyStoreLogger() {
		setConsoleLog();
	}
	
	/**
	 * This function resets the level of logs displayed on the console to Finer. 
	 * It also creates a handler that is required to write the logs into an associated file. 
	 */
	public void setConsoleLog() {
		//Changing the level of logs displayed on the console. 
		LogManager.getLogManager().reset();
		LOGR.setLevel(Level.FINER);
		
		ConsoleHandler ch = new ConsoleHandler();
		ch.setLevel(Level.ALL);
		LOGR.addHandler(ch);
		
		// Creating the handler which writes the logs to a file in the doc folder. 
		try {
			FileHandler fh = new FileHandler("doc/logs/ToyStoreCompanyLog.log");
			fh.setLevel(Level.ALL);
			LOGR.addHandler(fh);
		} catch (SecurityException e) {
			e.getMessage();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
	}
	
	/**
	 * Use to write logs in which an action is completed by the program. 
	 * @param s String corresponding to the message stored in the log. Specific to the action completed.
	 */
	public void logAction(String s) {
		LOGR.log(Level.INFO,s);
	}
	
	/**
	 * Use to write logs in which an error occurs in the program.
	 * @param s String corresponding to the message stored in the log. Specific for the error that occurs. 
	 */
	public void logError(String s) {
		LOGR.log(Level.WARNING,s);
	}
	
	/**
	 * This method writes logs in which an exception has occured in the program. 
	 * @param s String corresponding to the message stored in the log. Specific for the exception that occured. 
	 */
	public void logException(String s) {
		LOGR.log(Level.WARNING,s);
	}
	
	
}
