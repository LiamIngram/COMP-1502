package controller;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Logger;

import exceptions.InappropriateMinimumException;
import exceptions.NegativePriceException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.text.Text;
import model.Animal;
import model.Figure;
import model.Game;
import model.Puzzle;
import model.Toy;

/**
 * This class contains functions that manage the GUI of the application. It acts the controller to
 * enact certain procedures on the data stored or provide certain outputs based on actions completed
 * in the GUI. 
 * 
 * Also implements initializable interface which sets up any displays on launch. 
 * @author Tejas Gill, Liam Ingram
 * @version March 31, 2024
 */
public class ToyStoreManager implements Initializable {
		
	AppManager am;					// Declare AppManager object
	ToyStoreLogger tsl;				// Declare the logger for the controller
	ArrayList<Toy> inventory; 		// Declare ArrayList of Toys. All toys from the database will be loaded into this single ArrayList. 
	String input; 					// Declare String to hold inputs from user
	ArrayList<Toy> collection; 		// Declare arrayList that will hold specific arrayList of toys for methods
	private final String FILE_PATH = "res/toys.txt"; // File path for the database of all inventory toys
	private String[] toyTypes = { "Figure", "Animal", "Board Game","Puzzle" };	//String array to load into combo box
	private String[] figureClasses = { "Action", "Doll", "Historic" };	//String array to load into combo box
	private String[] sizes = { "Small", "Medium", "Large" };	//String array to load into combo box
	private String[] puzzleTypes = { "Mechanical", "Cryptic", "Logic", "Trivia", "Riddle" };	//String array to load into combo box
	
	/**
	 * Constructor for the ToyStoreManager class. 
	 * It initializes an object from AppManager and ToyStoreLogger. It also
	 * loads an arrayList with the data from the database. 
	 */
	public ToyStoreManager() {
		am = new AppManager();
		tsl = new ToyStoreLogger();
		inventory = am.loadData();
	}
	
	/**
	 * Textfield where the user can provide information on the age appropriate range for a new toy. 
	 */
    @FXML
    private TextField addAgeAppropriate;

    /**
	 * Textfield where the user can provide information on the available stock for a new toy. 
	 */
    @FXML
    private TextField addAvailableCount;

    /**
	 * Textfield where the user can provide information on the brand for a new toy. 
	 */
    @FXML
    private TextField addBrand;

    /**
	 * Textfield where the user can provide information on the name for a new toy. 
	 */
    @FXML
    private TextField addName;

    /**
	 * Button that user clicks when they are ready to add new toy.  
	 */
    @FXML
    private Button addNewToyButton;

    /**
	 * Textfield where the user can provide information on the price for a new toy. 
	 */
    @FXML
    private TextField addPrice;

    /**
	 * Textfield where the user can provide information on the serial number for a new toy. 
	 */
    @FXML
    private TextField addSerialNumber;

    /**
	 * Button that the user clicks when they wish to buy an selected item in the listview. 
	 */
    @FXML
    private Button buyButton;

    /**
     * Drop-down menu that allows the user to select the toy type for the new toy they wish to make. 
     */
    @FXML
    private ComboBox<String> category;

    /**
     * Check box for age if user wishes to make a gift suggestion using that information. 
     */
    @FXML
    private CheckBox checkAge;

    /**
     * Check box for price if user wishes to make a gift suggestion using that information. 
     */
    @FXML
    private CheckBox checkPrice;

    /**
     * Check box for toy type if user wishes to make a gift suggestion using that information. 
     */
    @FXML
    private CheckBox checkType;

    /**
     * Button used to clear all inputs on the search inventory tab. 
     */
    @FXML
    private Button clearButton;

    /**
     * Button completes search for toys based on the provided information.
     */
    @FXML
    private Button completeSearchButton;

    /**
     * Textfield for designers of a board game.
     */
    @FXML
    private TextField designers;

    /**
     * Type of figure the user wishes to make. 
     */
    @FXML
    private ComboBox <String> figureClassification;

    /**
     * Textfield for the age that the user wants to use for the gift suggestion.
     */
    @FXML
    private TextField giftAge;

    /**
     * Button that allows user to buy a selected item from the gift list view.  
     */
    @FXML
    private Button giftBuyButton;

    /**
     * Listview that displays gift items found based on the gift search completed.  
     */
    @FXML
    private ListView<Toy> giftList;

    /**
     * Textfield holding information on the price to use in the gift suggestion. 
     */
    @FXML
    private TextField giftPrice;

    /**
     * Button to be used to complete the gift search.
     */
    @FXML
    private Button giftSearchButton;

    /**
     * Button to be used to go to the gift suggestion tab. 
     */
    @FXML
    private Button giftSuggestionButton;

    /**
     * Combo Box for the toy type to use in gift suggestion.
     */
    @FXML
    private ComboBox<String> giftType;

    /**
     * Toggle to group radio buttons on search inventory tab.
     */
    @FXML
    private ToggleGroup group1;

    /**
     * Textfield to hold the material of a toy. 
     */
    @FXML
    private TextField material;

    /**
     * Textfield to hold the max players that can play a board game.
     */
    @FXML
    private TextField maxPlayer;

    /**
     * Textfield to hold the min players that can play a board game.
     */
    @FXML
    private TextField minPlayer;

    /**
     * ComboBox to hold the puzzle type of a toy. 
     */
    @FXML
    private ComboBox<String> puzzleType;

    /**
     * Radio button to select search based on name.
     */    
    @FXML
    private RadioButton rbName;

    /**
     * Radio button to select search based on serial number.
     */ 
    @FXML
    private RadioButton rbSerial;

    /**
     * Radio button to select search based on toy type.
     */ 
    @FXML
    private RadioButton rbType;

    /**
     * Button used to to tab to remove a toy. 
     */ 
    @FXML
    private Button removeButton;

    /**
     * List view which displays the toy that the user would like to remove.
     */ 
    @FXML
    private ListView<Toy> removeList;

    /**
     * Textfield that holds the serial number of the toy the user would like to remove. 
     */ 
    @FXML
    private TextField removeSerialNumber;
    
    /**
     * TabPane which holds all the tabs of the GUI. 
     */ 
    @FXML
    private TabPane tabPane;

    /**
     * Button used to remove a toy.
     */
    @FXML
    private Button removeToyButton;
    
    /**
     * Button used when user wishes to save. 
     */
    @FXML
    private Button saveButton;

    /**
     * Button used when user wishes to complete a search of the inventory.
     */
    @FXML
    private Button searchInventButton;

    /**
     * List view which displays toys captured in the inventory search.
     */
    @FXML
    private ListView<Toy> searchList;

    /**
     * Textfield holding the name the user would like to use to search the inventory.
     */
    @FXML
    private TextField searchName;

    /**
     * Textfield holding the serial number the user would like to use to search the inventory.
     */
    @FXML
    private TextField searchSerialNumber;

    /**
     * Combo Box holding the toy type the user would like to use to search the inventory.
     */
    @FXML
    private  ComboBox<String> searchType;

    /**
     * ComboBox holding the size of a toy the user would like to make. 
     */
    @FXML
    private ComboBox<String> size;
    
    /**
     * Label to share messages with user of errors or success in their actions.
     */
    @FXML
    private Label searchConsole;
    
    /**
     * Label to share messages with user of errors or success in their actions.
     */
    @FXML
    private Label addToyConsole;
    
    /**
     * Label to share messages with user of errors or success in their actions.
     */
    @FXML
    private Label giftConsole;
    
    /**
     * Label to share messages with user of errors or success in their actions.
     */
    @FXML
    private Label removeConsole;
    
    /**
     * Button to remove toy item following search. 
     */
    @FXML
    private Button searchRemove;
    
    /**
     * Label for SN
     */
    @FXML
    private Text snLabel;
    
    /**
     * Label for name
     */
    @FXML
    private Text nameLabel;
    
    /**
     * Label for toy type
     */
    @FXML
    private Text typeLabel;
    
    /**
     * Label for figure section
     */
    @FXML
    private Label figureLabel;
    
    /**
     * Label for puzzle section
     */
    @FXML
    private Label puzzleLabel;
    
    /**
     * Label for animal section
     */
    @FXML
    private Label animalLabel;
    
    /**
     * Label for board game section
     */
    @FXML
    private Label gameLabel;
    
    /**
     * Label for classification input
     */
    @FXML
    private Label classLabel;
    
    /**
     * Label for puzzle type input
     */
    @FXML
    private Label pType;
    
    /**
     * Label for material input
     */
    @FXML
    private Label materialLabel;
    
    /**
     * Label for size input
     */
    @FXML
    private Label sizeLabel;
    
    /**
     * Label for minimum player input
     */
    @FXML
    private Label minLabel;
    
    /**
     * Label for maximum player input
     */
    @FXML
    private Label maxLabel;
    
    /**
     * Label for designers input
     */
    @FXML
    private Label designersLabel;

    /**
     * This eventHandler responds when the user chooses to buy an selected item from the list view
     * after having completed a search in the inventory. 
     * @param event Clicking of the Buy button on the search tab. 
     */
    @FXML
    void buySearchItem(ActionEvent event) {
    	// Get the index of the item from the searchList selected, also the toy object itself.
    	int finalDecision = searchList.getSelectionModel().getSelectedIndex();
    	Toy t = searchList.getSelectionModel().getSelectedItem();
    	
    	// If there is no stock for the toy.
    	if (t.getStock()==0) {
    		searchConsole.setText("There is not stock remaining for this toy. Cannot complete purchase.");
    		tsl.logAction("User attempted to buy item, however no stock was remaining.");	// log that an item is out of stock
    	}
    	// If there is remaining stock for the toy.
    	else {
    		inventory = am.purchase(finalDecision);
        	searchList.getItems().clear();	//Reset the display of the list view to display changes in stock.
        	
        	ObservableList<Toy> searchDisplay = FXCollections.observableArrayList(collection);
        	searchList.getItems().addAll(searchDisplay);
        	
        	searchConsole.setText("Successful Purhcase!"); // Success of purchase 
        	tsl.logAction("Item was bought from search inventory");	//Log that an item was bought
    	}
    	saveData(); // Save data after altercations due to buying. 
    	
    }

    /**
     * This eventHandler clears all the input provided on the search tab.
     * @param event Clicking of the clear button. 
     */
    @FXML
    void clearInput(ActionEvent event) {
    	rbSerial.setSelected(false);
    	rbName.setSelected(false);
    	rbType.setSelected(false);
    	
    	searchSerialNumber.clear();
    	searchName.clear();
    	searchList.getItems().clear();
    	
    	searchConsole.setText("");
    	tsl.logAction("Input on search inventory tab was cleared."); // Log that the inputs on search tab were cleared.
    }
    
    /**
     * Clears the add Toy page
     */
    
    @FXML
    void clearAdd() {
    	category.setValue("Select Toy Type");
    	addSerialNumber.clear();
    	addName.clear();
    	addAgeAppropriate.clear();
    	addAvailableCount.clear();
    	addBrand.clear();
    	addPrice.clear();
    	addSerialNumber.setPromptText("Enter Unique SIN");
    	addName.setPromptText("Enter Toy Name");
    	addAgeAppropriate.setPromptText("Enter Age");
    	addAvailableCount.setPromptText("Enter Stock");
    	addBrand.setPromptText("Enter Brand");
    	addPrice.setPromptText("Enter Price");
    	
    	figureClassification.setValue(null);
    	
    	material.clear();
    	size.setValue(null);
    	
    	puzzleType.setValue(null);
    	
    	minPlayer.clear();
    	maxPlayer.clear();
    	designers.clear();
    	
    	figureLabel.setStyle("-fx-text-fill: black;");
		classLabel.setStyle("-fx-text-fill: black;");
		
		animalLabel.setStyle("-fx-text-fill: black;");
		materialLabel.setStyle("-fx-text-fill: black;");
		sizeLabel.setStyle("-fx-text-fill: black;");
		
		puzzleLabel.setStyle("-fx-text-fill: black;");
		pType.setStyle("-fx-text-fill: red;");
		
		gameLabel.setStyle("-fx-text-fill: black;");
		minLabel.setStyle("-fx-text-fill: black;");
		maxLabel.setStyle("-fx-text-fill: black;");
		designersLabel.setStyle("-fx-text-fill: black;");
    	
    }

    /**
     * This eventHandler allows the user to create a toy to add to the inventory. 
     * @param event	Click on the add toy button. 
     * @throws NegativePriceException	This exception is thrown when the price provided for the toy is negative.
     * @throws InappropriateMinimumException This exception is thrown when the minimum number of players for a board game is impossible.
     */
    @FXML
    void createNewToy(ActionEvent event) throws NegativePriceException, InappropriateMinimumException {
    	Toy t = null;
    	boolean invalid = false;
    	addToyConsole.setText(""); //Clear any pre-existing error messages in the label.
    	
    	String serial = addSerialNumber.getText(); // Retrieve the serial number provided by the user.
    	
    	// If the serial number is not valid. Which will occur if the returning string is not null.
    	if (am.validateSerialNumber(serial)!=null) {
    		addToyConsole.setText(am.validateSerialNumber(serial));
    		invalid=true;
    		tsl.logError("The serial number provided was invalid because: "+am.validateSerialNumber(serial));
    	} else {
    	
    	/*
    	 * Additional user input
    	 */
    	String name = addName.getText();
    	String brand = addBrand.getText();
    	Double price = Double.parseDouble(addPrice.getText());
    	
    	//Check if the price provided is negative and throw exception.
    	if (price<0) {
    		addToyConsole.setText("The Price provided was negative, please try again!");
    		tsl.logException("A negative price was provided for a new toy.");
    		throw new NegativePriceException();
    	}
    	
    	
    	/*
    	 * Take additional input
    	 */
    	int stock = Integer.parseInt(addAvailableCount.getText());
    	int minAge = Integer.parseInt(addAgeAppropriate.getText());
    	
    	/*
		 * Prompt user for more information based on the type of toy they wish to make. 
		 * This is determined based on the serial number provided. 
		 * To prompt for additional information, the serial number must be valid(i.e. invalid must be false)
		 * and the correct selection must be made using the combobox that matches the serial number.
		 */
		if ( !invalid && (serial.charAt(0)=='1' || serial.charAt(0)=='0') && category.getValue().equalsIgnoreCase("figure")) {
			char type = figureClassification.getValue().trim().toUpperCase().charAt(0);
			t = new Figure(serial, name, brand, price, stock, minAge,type);
			clearAdd();
		}
		else if (!invalid && (serial.charAt(0)=='2' || serial.charAt(0)=='3') && category.getValue().equalsIgnoreCase("animal")) {
			String inputMaterial = material.getText();
			char size = this.size.getValue().trim().toUpperCase().charAt(0);
			t = new Animal(serial, name, brand, price, stock, minAge,inputMaterial,size);
			clearAdd();
		}
		else if (!invalid && (serial.charAt(0)=='4' || serial.charAt(0)=='5' || serial.charAt(0)=='6')&& category.getValue().equalsIgnoreCase("puzzle")) {
			char type = puzzleType.getValue().trim().toUpperCase().charAt(0);
			t = new Puzzle(serial, name, brand, price, stock, minAge,type);
			clearAdd();
		}
		else if (!invalid && (serial.charAt(0)=='7' || serial.charAt(0)=='8' || serial.charAt(0)=='9')&& category.getValue().equalsIgnoreCase("board game")){
			int minPlayer = Integer.parseInt(this.minPlayer.getText());
			int maxPlayer = Integer.parseInt(this.maxPlayer.getText());
			
			// Throw exception for inappropriate minimum number of players. 
			if(minPlayer>maxPlayer) {
				addToyConsole.setText("The minimum numbers of players provided is higher than the maximum, please try again!");
				tsl.logException("A invalid input was provided for minimum and maximum number of players.");
				throw new InappropriateMinimumException();
			}
			
			String [] designers = this.designers.getText().split(",");
			t = new Game(serial, name, brand, price, stock, minAge, minPlayer, maxPlayer, designers);
			clearAdd();
		}
		else {
			addToyConsole.setText("The category selected does not match the information provided, please try again.");
			tsl.logError("The provided serial number did not match the toy type the user attempted to create. ");
		}
		
		// Add the new toy if it created properly
		if(t!=null) {
			inventory.add(t);		//Toy is added to inventory
			tsl.logAction("New toy was successfully added to the inventory");
			saveData();
		}
    	}
		
    }

    /**
     * This eventHandler allows the user to buy an item that was suggested as a gift.
     * @param event In response to the click on the buy button on the gift tab.
     */
    @FXML
    void giftBuy(ActionEvent event) {
    	// Get both the index of the item selected and store it as a toy. 
    	int finalDecision = giftList.getSelectionModel().getSelectedIndex();
    	Toy t = giftList.getSelectionModel().getSelectedItem();
    	
    	// If the stock of the item is 0
    	if (t.getStock()==0) {
    		giftConsole.setText("There is not stock remaining for this toy. Cannot complete purchase.");
    		tsl.logAction("User attempted to buy item, however no stock was remaining.");
    	}
    	// If the stock of the item is not 0
    	else {
    		inventory = am.purchase(finalDecision);
        	giftList.getItems().clear(); //Clear list such that it can update to reflect changes.
        	ObservableList<Toy> searchDisplay = FXCollections.observableArrayList(collection);
        	giftList.getItems().addAll(searchDisplay);
        	giftConsole.setText("Successful Purhcase!");
        	tsl.logException("User successfully bought an item.");
    	}
    	saveData();
    }

    /**
     * This eventHandler completes a gift search based on the information provided. 
     * The resulting arrayList is displayed in the gift list view.
     * @param event Clicking of the search button on the gift tab.
     */
    @FXML
    void giftSearch(ActionEvent event) {
    	// Initialize variables
    	int choice=0;
    	int age=-1;
    	char type='z';
    	Double minPrice=-10.0;
    	Double maxPrice=-12.0;
    	String priceRange = null;
    	giftConsole.setText("");	//Clear the console
    	
    	/*
    	 * If-then statement that changes the value of choice based on the information the user
    	 * indicated they want to use in their gift search.
    	 */
    	if (checkAge.isSelected()) {
    		age = Integer.parseInt(giftAge.getText());
    		choice = 1;
    		
    		if (checkType.isSelected()) {
    			type = giftType.getValue().trim().toUpperCase().charAt(0);
    			choice =4;
    			
    			if(checkPrice.isSelected()) {
    				priceRange = giftPrice.getText();
    				choice = 7;
    			}
    		}
    		else if (checkPrice.isSelected()) {
    			priceRange = giftPrice.getText();
    			choice = 5;
    		}
    	}
    	else if(checkType.isSelected()) {
    		type = giftType.getValue().trim().toUpperCase().charAt(0);
			choice =2;
			
			if(checkPrice.isSelected()) {
				priceRange = giftPrice.getText();
				choice = 6;
			}
    	}
    	else if(checkPrice.isSelected()) {
    		priceRange = giftPrice.getText();
			choice = 3;
    	}
    	else {
    		giftConsole.setText("No information was selected to be provided. Please try agaiun.");
    		tsl.logError("The user did not select any checkboxs.");
    	}
    	
    	// If a value for price range was provided, this will split it into a min and max.
    	if (priceRange!=null) {
    		String[] splitPrice = priceRange.split("-");
    		minPrice=Double.parseDouble(splitPrice[0]);
			maxPrice=Double.parseDouble(splitPrice[1]);
    	}
    	
    	/*
    	 * This will create a toy collection based on the gift parameters provided.
    	 * Display these items on the gift list view.
    	 */
    	collection = am.findAllToys(choice,age,minPrice,maxPrice,type);
    	giftList.getItems().clear();
        ObservableList<Toy> searchDisplay = FXCollections.observableArrayList(collection);
        giftList.getItems().addAll(searchDisplay);
    	
    }

    /**
     * This eventHandler will remove a toy selected by the user.
     * @param event Clicking of the remove button.
     */
    @FXML
    void removeToy(ActionEvent event) {
    	String serial = removeSerialNumber.getText();
    	inventory = am.removeToy(serial);
    	
        removeList.getItems().clear();	//Refresh the list view
    	collection = am.findSerialNumber(serial);
        ObservableList<Toy> searchDisplay = FXCollections.observableArrayList(collection);
        removeList.getItems().addAll(searchDisplay);
        saveData();
        tsl.logAction("A toy was removed from the inventory.");
    }

    /**
     * This eventHandler completes a search of the inventory based on the information provided by the user.
     * The resulting toys are displayed on the list view.
     * @param event Clicking of the search button on the search tab.
     */
    @FXML
    void searchInventory(ActionEvent event) {
    	searchList.getItems().clear(); // Reset the list view in case a previous search was completed.
    	
    	/*
    	 * Based on the radio button selected, a collection of toys with the corresponding information
    	 * will be provided.
    	 */
    	if(rbSerial.isSelected()) {
    		input = searchSerialNumber.getText();
    		collection = am.findSerialNumber(input);
    	}
    	else if(rbName.isSelected()) {
    		input = searchName.getText();
    		collection = am.findToyName(input);
    	}
    	else if (rbType.isSelected()) {
    		input = searchType.getValue();
    		collection = am.findToyType(input);
    	}
    	else {
    		searchConsole.setText("The type of search was not specified, please try again. ");
    		tsl.logError("User did not specify the type of information to use in search.");
    	}
    	
    	// Check if no items match the search
    	if(collection.size()==0) {
    		searchConsole.setText("No Toy was Found!");
    	}
    	
    	// Displays the final collection of toys
    	ObservableList<Toy> searchDisplay = FXCollections.observableArrayList(collection);
    	searchList.getItems().addAll(searchDisplay);
    	tsl.logAction("A search of the inventory was completed.");
    }

    /**
     * This eventHandler completes a search for an toy based on serial number that the user wants to remove.
     * @param event Clicking the search button on the remove toy tab.
     */
    @FXML
    void searchToy(ActionEvent event) {
    	removeList.getItems().clear(); //Refresh list is previous search was completed.
    	
    	String serial = removeSerialNumber.getText();
    	collection = am.findSerialNumber(serial);
    	
    	ObservableList<Toy> searchDisplay = FXCollections.observableArrayList(collection);
    	removeList.getItems().addAll(searchDisplay);
    	tsl.logAction("A search to remove a toy from the inventory was completed.");
    }
    
    /**
     * EventHandler moves to the add new toy tab when button is clicked.
     * @param event Clicking the add new toy button on the home page.
     */
    @FXML
    void toAddNewToy(ActionEvent event) {
    	tabPane.getSelectionModel().select(2);
    }

    /**
     * EventHandler moves to the gift suggestion tab when button is clicked.
     * @param event Clicking the gift suggestion button on the home page.
     */
    @FXML
    void toGiftSearch(ActionEvent event) {
    	tabPane.getSelectionModel().select(4);
    }

    /**
     * EventHandler moves to the remove toy tab when button is clicked.
     * @param event Clicking the remove toy button on the home page.
     */
    @FXML
    void toRemoveToy(ActionEvent event) {
    	tabPane.getSelectionModel().select(3);
    }

    /**
     * EventHandler moves to the search inventory tab when button is clicked.
     * @param event Clicking the search inventory button on the home page.
     */
    @FXML
    void toSearchInvent(ActionEvent event) {
    	tabPane.getSelectionModel().select(1);
    }

    /**
     * Method initializes any FX features on the launch of the GUI.
     * Initializes combo boxes
     */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		category.getItems().addAll(toyTypes);	
		searchType.getItems().addAll(toyTypes); 
		giftType.getItems().addAll(toyTypes);
		figureClassification.getItems().addAll(figureClasses);
		size.getItems().addAll(sizes);
		puzzleType.getItems().addAll(puzzleTypes);
	}
	
	/**
	 * This function writes the list of toys in the inventory back to the database.
	 * Of note, it adjusts what information is written based on the specific type of
	 * toy.
	 */
	public void saveData() {
		FileWriter fw = null;

		try {
			fw = new FileWriter(FILE_PATH, false);
		} catch (IOException e) {
			e.printStackTrace();
		}

		PrintWriter pw = new PrintWriter(fw);

		Figure figure;
		Puzzle puzzle;
		Game game;
		Animal animal;

		/*
		 * For each toy in inventory, the type is checked using instanceOf and based on
		 * the type of toy the toy is converted between objects and the format function
		 * is used to print the relevant information to the database.
		 */
		for (Toy toy : inventory) {
			if (toy instanceof Figure) {
				figure = (Figure) toy;
				pw.println(figure.format());
			} else if (toy instanceof Puzzle) {
				puzzle = (Puzzle) toy;
				pw.println(puzzle.format());
			} else if (toy instanceof Game) {
				game = (Game) toy;
				pw.println(game.format());
			} else if (toy instanceof Animal) {
				animal = (Animal) toy;
				pw.println(animal.format());
			}
		}
		pw.close();
		
		tsl.logAction("A save of the data was completed.");
	
	}
	
	/**
	 * Selects SN as the active field
	 * 
	 * @param event
	 */
	
	@FXML
	void snHandler(ActionEvent event) {
		
		snLabel.setStyle("-fx-fill: red;");
		nameLabel.setStyle("-fx-fill: black;");
		typeLabel.setStyle("-fx-fill: black;");
		
		searchSerialNumber.setPromptText("Enter SN Here");
		searchName.setPromptText(" ");
		searchType.setPromptText(" ");
	}
	
	/**
	 * Selects Name as the active field
	 * 
	 * @param event
	 */
	
	@FXML
	void nameHandler(ActionEvent event) {
		
		snLabel.setStyle("-fx-fill: black;");
		nameLabel.setStyle("-fx-fill: red;");
		typeLabel.setStyle("-fx-fill: black;");
		
		searchSerialNumber.setPromptText(" ");
		searchName.setPromptText("Enter Name Here");
		searchType.setPromptText(" ");
	}
	
	/**
	 * Selects Type as the active field
	 * 
	 * @param event
	 */
	
	@FXML
	void typeHandler(ActionEvent event) {
		
		snLabel.setStyle("-fx-fill: black;");
		nameLabel.setStyle("-fx-fill: black;");
		typeLabel.setStyle("-fx-fill: red;");
		
		searchSerialNumber.setPromptText(" ");
		searchName.setPromptText(" ");
		searchType.setPromptText("Select Toy Type");
	}
	
	/**
	 * Selects the required parrameters for adding a toy
	 * 
	 * @param event
	 */
	
	@FXML
	void categoryHandler(ActionEvent event) {
		
		if (category.getValue().equalsIgnoreCase("figure")) {
			
			figureLabel.setStyle("-fx-text-fill: red;");
			classLabel.setStyle("-fx-text-fill: red;");
			
			animalLabel.setStyle("-fx-text-fill: black;");
			materialLabel.setStyle("-fx-text-fill: black;");
			sizeLabel.setStyle("-fx-text-fill: black;");
			
			puzzleLabel.setStyle("-fx-text-fill: black;");
			pType.setStyle("-fx-text-fill: black;");
			
			gameLabel.setStyle("-fx-text-fill: black;");
			minLabel.setStyle("-fx-text-fill: black;");
			maxLabel.setStyle("-fx-text-fill: black;");
			designersLabel.setStyle("-fx-text-fill: black;");
			
			
			figureClassification.setPromptText("Choose A Class");
			
			material.setPromptText(" ");
			size.setPromptText(" ");
			
			puzzleType.setPromptText(" ");
			
			minPlayer.setPromptText(" ");
			maxPlayer.setPromptText(" ");
			designers.setPromptText(" ");
			
			
		}else if (category.getValue().equalsIgnoreCase("animal")) {
			
			figureLabel.setStyle("-fx-text-fill: black;");
			classLabel.setStyle("-fx-text-fill: black;");
			
			animalLabel.setStyle("-fx-text-fill: red;");
			materialLabel.setStyle("-fx-text-fill: red;");
			sizeLabel.setStyle("-fx-text-fill: red;");
			
			puzzleLabel.setStyle("-fx-text-fill: black;");
			pType.setStyle("-fx-text-fill: black;");
			
			gameLabel.setStyle("-fx-text-fill: black;");
			minLabel.setStyle("-fx-text-fill: black;");
			maxLabel.setStyle("-fx-text-fill: black;");
			designersLabel.setStyle("-fx-text-fill: black;");
			
			
			figureClassification.setPromptText(" ");
			
			material.setPromptText("Enter Material");
			size.setPromptText("Choose A Size");
			
			puzzleType.setPromptText(" ");
			
			minPlayer.setPromptText(" ");
			maxPlayer.setPromptText(" ");
			designers.setPromptText(" ");
			
		}else if (category.getValue().equalsIgnoreCase("puzzle")) {
			
			figureLabel.setStyle("-fx-text-fill: black;");
			classLabel.setStyle("-fx-text-fill: black;");
			
			animalLabel.setStyle("-fx-text-fill: black;");
			materialLabel.setStyle("-fx-text-fill: black;");
			sizeLabel.setStyle("-fx-text-fill: black;");
			
			puzzleLabel.setStyle("-fx-text-fill: red;");
			pType.setStyle("-fx-text-fill: red;");
			
			gameLabel.setStyle("-fx-text-fill: black;");
			minLabel.setStyle("-fx-text-fill: black;");
			maxLabel.setStyle("-fx-text-fill: black;");
			designersLabel.setStyle("-fx-text-fill: black;");
			
			
			figureClassification.setPromptText(" ");
			
			material.setPromptText(" ");
			size.setPromptText(" ");
			
			puzzleType.setPromptText("Choose A Type");
			
			minPlayer.setPromptText(" ");
			maxPlayer.setPromptText(" ");
			designers.setPromptText(" ");
			
		}else if (category.getValue().equalsIgnoreCase("board game")) {
			
			figureLabel.setStyle("-fx-text-fill: black;");
			classLabel.setStyle("-fx-text-fill: blac;");
			
			animalLabel.setStyle("-fx-text-fill: black;");
			materialLabel.setStyle("-fx-text-fill: black;");
			sizeLabel.setStyle("-fx-text-fill: black;");
			
			puzzleLabel.setStyle("-fx-text-fill: black;");
			pType.setStyle("-fx-text-fill: black;");
			
			gameLabel.setStyle("-fx-text-fill: red;");
			minLabel.setStyle("-fx-text-fill: red;");
			maxLabel.setStyle("-fx-text-fill: red;");
			designersLabel.setStyle("-fx-text-fill: red;");
			
			
			figureClassification.setPromptText(" ");
			
			material.setPromptText(" ");
			size.setPromptText(" ");
			
			puzzleType.setPromptText(" ");
			
			minPlayer.setPromptText("Enter min");
			maxPlayer.setPromptText("Enter max");
			designers.setPromptText("Enter Designers");
			
			
		}
	}
	
}
