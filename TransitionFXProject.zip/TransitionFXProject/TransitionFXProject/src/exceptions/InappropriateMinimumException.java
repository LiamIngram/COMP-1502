package exceptions;

/**
 * Exception class for when the minimum number of players provided is higher than the maximum value provided by the user.  
 */
public class InappropriateMinimumException extends Exception {

	/**
	 * Constructor for this exception class.
	 * Passes the error message regarding an invalid minimum number of players to the exception super class. 
	 */
	public InappropriateMinimumException() {
		super("Error: The minimum nuymber of players cannot be greater than the maximum");
	}
}
