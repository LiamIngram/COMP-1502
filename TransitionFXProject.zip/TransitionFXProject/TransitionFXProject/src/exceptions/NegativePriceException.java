package exceptions;

/**
 * Exception class for when the price provided for a new toy is negative. 
 */
public class NegativePriceException extends Exception {
	
	/**
	 * Constructor for the Negative Price Exception, passes the error message to the exception super class. 
	 */
	public NegativePriceException() {
		super("Error: The input price for a new toy cannot be negative. ");
	}
}
