package model;

/**
 * Model class for the animal type toys. This class is used to create animal objects and modify the data provided for suitable use in other methods/classes. 
 * @author Tejas Gill, Liam Ingram
 * @version March 10, 2024
 */
public class Animal extends Toy{
	
	private String material;						// A description of the material this toy is made from.
	private char size;								// Size of the toy: Small, Medium, or Large.
	
	/**
	 * Constructor for the Animal class, which instantiates all relevant fields for the Animal object upon call. 
	 * @param se Serial number of the toy, a unique 10-digit number for the toy.
	 * @param n Name of the item.
	 * @param b Brand name of the toy.
	 * @param p Cost to purchase the toy.
	 * @param st Number of copies of this item currently in stock.
	 * @param a The suggested minimum age to use this item.
	 * @param m A description of the material this toy is made from.
	 * @param s Size of the toy: Small, Medium, or Large.
	 */
	public Animal(String se, String n, String b, double p, 
			int st, int a, String m, char s) {
		super(se, n, b, p, st, a);
		this.material = m;
		this.size = s;
	}

	/**
	 * Method returns the description of the material that the animal object is made from. 
	 * @return A string that holds an description of the material that the animal object is made from. 
	 */
	public String getMaterial() {
		return material;
	}

	/**
	 * Method modifies the description for the material from which a toy is made to the description that is passed to the method upon call. 
	 * @param material This is the a string that holds the new material description that should be applied to the animal object. 
	 */
	public void setMaterial(String material) {
		this.material = material;
	}

	/**
	 * Method returns the size of the animal object. 
	 * @return	A char data type is returned corresponding to the size of the animal object that was specified on creation. 
	 */
	public char getSize() {
		return size;
	}

	/**
	 * Method modifies the size of the animal object to the char data type that is passed to the method upon call. 
	 * @param size This is the new size for the object that should be applied to the animal object. 
	 */
	public void setSize(char size) {
		this.size = size;
	}
		
	/**
	 * This method returns a string of the instance fields for a animal object formated appropriately for saving. 
	 * @return A string that encompasses all of the instance fields of a animal toy in a particular order, separated by semi-colons. 
	 */
	public String format() {
		return String.format(super.format() + "%s;%s"
				, this.material, this.size);
	}
	
	/**
	 * This method is the toString, which returns a string of the object's fields that is in human readable form. 
	 * @return A string that encompasses all of the fields of the Animal object after formating is returned. 
	 */
	public String toString() {
		return super.toString()+" Material: "+material+" Size: "+size;
	}

}
