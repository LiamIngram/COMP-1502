package model;

/**
 * Model class for the game type toys. This class is used to create game objects and modify the data provided for suitable use in other methods/classes. 
 * @author Tejas Gill, Liam Ingram
 * @version March 10, 2024
 */
public class Game extends Toy {
	
	private int minPlayer;						// The minimum number of players required to play the game. 
	private int maxPlayer;						// The maximum number of players that can play the game. 
	private String players;						// The range of players that can play the game formated as min-max. 
	private String[] designers;					// String array holding the different designers involved in creating the game. 
	
	/**
	 * Constructor for the Game class, which instantiates all relevant fields for the Animal object upon call. 
	 * This constructor is called when the constructor is passed a value for minimum and maximum players. 
	 * @param se Serial number of the toy, a unique 10-digit number for the toy.
	 * @param n Name of the item.
	 * @param b Brand name of the toy.
	 * @param p Cost to purchase the toy.
	 * @param st Number of copies of this item currently in stock.
	 * @param a The suggested minimum age to use this item.
	 * @param pl The minimum number of players required to play the game. 
	 * @param p2 The maximum number of players that can play the game. 
	 * @param d String array holding the different designers involved in creating the game. 
	 */
	public Game(String se, String n, String b, double p, 
			int st, int a, int pl, int p2, String[] d) {
		super(se, n, b, p, st, a);
		this.minPlayer = pl;
		this.maxPlayer = p2;
		this.designers = d;
		this.players=getPlayers();
	}
	
	/**
	 * Constructor for the Game class, which instantiates all relevant fields for the Animal object upon call. 
	 * This constructor is called when the constructor is passed a value for a range of players rather than a value for min and max players. 
	 * @param se Serial number of the toy, a unique 10-digit number for the toy.
	 * @param n Name of the item.
	 * @param b Brand name of the toy.
	 * @param p Cost to purchase the toy.
	 * @param st Number of copies of this item currently in stock.
	 * @param a The suggested minimum age to use this item.
	 * @param pl The range of players that can play the game formated as min-max. 
	 * @param d String array holding the different designers involved in creating the game. 
	 */
	public Game(String se, String n, String b, double p, 
			int st, int a, String pl, String[] d) {
		super(se, n, b, p, st, a);
		this.players = pl;
		this.designers = d;
		String [] splittedLine = pl.split("-");
		this.minPlayer=Integer.parseInt(splittedLine[0]);
		this.maxPlayer=Integer.parseInt(splittedLine[1]);
		
	}

	/**
	 * This method returns the range for the number of players that are permitted to play for this particular instance object. 
	 * @return A string that indicates the range for the number of players permitted to play. 
	 */
	public String getPlayers() {
		return minPlayer+"-"+maxPlayer;
	}

	/**
	 * This method modifies the minimum number of players assigned for a game object. 
	 * @param players This is the new value for minimum players that will be assigned to the object. 
	 */
	public void setMinPlayers(int players) {
		this.minPlayer = players;
	}
	
	/**
	 * This method modifies the maximum number of players assigned for a game object. 
	 * @param players This is the new value for maximum players that will be assigned to the object. 
	 */
	public void setMaxPlayer(int players) {
		this.maxPlayer = players;
	}

	/**
	 * This method returns the String array holding the different designers involved in creating the game. 
	 * @return The string array holding the different designers involved in creating the game. 
	 */
	public String[] getDesigners() {
		return designers;
	}

	/**
	 * This method modifies the String array holding the different designers involved in creating the game. 
	 * @param designers The string array holding the new list of designers involved in creating the game. 
	 */
	public void setDesigners(String[] designers) {
		this.designers = designers;
	}
		
	/**
	  * This method returns a string of the instance fields for a game object formated appropriately for saving. 
	 * @return A string that encompasses all of the instance fields of a game toy in a particular order, separated by semi-colons. 
	 */
	public String format() {
		String desTeam = "";
		for (String des : designers)
			desTeam += des + ",";	
		return String.format(super.format() + "%s;%s"
				, getPlayers(), desTeam);
	}
	
	/**
	 * This method is the toString, which returns a string of the object's fields that is in human readable form. 
	 * @return A string that encompasses all of the fields of the game object after formating is returned. 
	 */
	public String toString() {
		String desTeam = "";
		for (String des : designers)
			desTeam += des + ",";	
		return super.toString()+" Number of Players: "+getPlayers()+" Designers: "+desTeam;
	}
	

}
