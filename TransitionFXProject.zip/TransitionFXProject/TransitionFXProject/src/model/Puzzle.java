package model;

/**
 * Model class for the Puzzle type toys. This class is used to create puzzle objects and modify the data provided for suitable use in other methods/classes. 
 * @author Tejas Gill, Liam Ingram
 * @version March 10, 2024
 */
public class Puzzle extends Toy{
	
	private char type;								// Holds the puzzle type: Mechanical, Cryptic, Logic, Trivia, or Riddle.
	
	/**
	 * Constructor for the Puzzle class, which instantiates all relevant fields for the Puzzle object upon call. 
	 * @param se Serial number of the toy, a unique 10-digit number for the toy.
	 * @param n Name of the item.
	 * @param b Brand name of the toy.
	 * @param p Cost to purchase the toy.
	 * @param st Number of copies of this item currently in stock.
	 * @param a The suggested minimum age to use this item.
	 * @param t The puzzle type: Mechanical, Cryptic, Logic, Trivia, or Riddle.
	 */
	public Puzzle(String se, String n, String b, double p, 
			int st, int a, char t) {
		super(se, n, b, p, st, a);
		this.type = t;
	}

	/**
	 * This method returns the puzzle type of the Puzzle object. 
	 * @return The puzzle type as conveyed by a char data type is returned. 
	 */
	public char getType() {
		return type;
	}

	/**
	 * This method modifies the puzzle type of the Puzzle object. 
	 * @param type The new puzzle type to be assigned to the puzzle object.  
	 */
	public void setType(char type) {
		this.type = type;
	}

	/**
	 * This method returns a string of the instance fields for a puzzle object formated appropriately for saving. 
	 * @return A string that encompasses all of the instance fields of a puzzle toy in a particular order, separated by semi-colons. 
	 */
	public String format() {
		return String.format(super.format() + "%s", this.type);
	}
	
	/**
	 * This method is the toString, which returns a string of the object's fields that is in human readable form. 
	 * @return A string that encompasses all of the fields of the Puzzle object after formating is returned.  
	 */
	public String toString() {
		return super.toString()+" Puzzle-type: "+type;
	}

}
