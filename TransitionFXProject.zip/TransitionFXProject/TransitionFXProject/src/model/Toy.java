package model;

/**
 * Abstract class that holds shared properties by all the different types of toys. This class cannot be instantiated. 
 * @author Tejas Gill, Liam Ingram
 * @version March 10, 2024
 */
public abstract class Toy {
	
	private String serial;		//Serial number of the toy, a unique 10-digit number for the toy.
	private String name;		//Name of the item.
	private String brand;		//Brand name of the toy.
	private double price;		//Cost to purchase the toy.
	private int stock;			//Number of copies of this item currently in stock.
	private int minAge;			//The suggested minimum age to use this item.
	private String category;	//The type of toy category this object falls within.
	
	/**
	 * Constructor for the toy class, which instantiates all relevant fields for the Toy object upon call. 
	 * @param se Serial number of the toy, a unique 10-digit number for the toy.
	 * @param n Name of the item.
	 * @param b Brand name of the toy.
	 * @param p Cost to purchase the toy.
	 * @param st Number of copies of this item currently in stock.
	 * @param a The suggested minimum age to use this item.
	 */
	public Toy(String se, String n, String b, double p,
			int st, int a) {
		this.serial = se;
		this.name = n;
		this.brand = b;
		this.price = p;
		this.stock = st;
		this.minAge = a;
		this.category=category();
	}
		
	/**
	 * Method returns the serial number for a toy object. 
	 * @return A string denoting the serial number of the toy object is returned. 
	 */
	public String getSerial() {
		return serial;
	}

	/**
	 * Method allows serial number for a toy object to be modified to the parameter passed to the function. 
	 * @param serial The new serial number that a toy object should be adjusted to have. 
	 */
	public void setSerial(String serial) {
		this.serial = serial;
	}

	/**
	 * Method returns the name for a toy. 
	 * @return A string corresponding to the name of the toy item is returned. 
	 */
	public String getName() {
		return name;
	}

	/**
	 * Method modifies the name of the toy to the string passed to the function on the call. 
	 * @param name This is the new name to be assigned to the instance toy object. 
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Method returns the brand name of the toy. 
	 * @return String that denotes the brand name of the toy. 
	 */
	public String getBrand() {
		return brand;
	}

	/**
	 * Method modifies the brand name of the toy to the string passed to the function on the call. 
	 * @param brand This is the new brand name to be assigned to the instance toy object. 
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}

	/**
	 * Method returns the price of the toy.
	 * @return The price to purchase the toy. 
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * Method modifies the price of the toy to the double passed to the function on the call. 
	 * @param price This is the new price to be assigned to the instance toy object. 
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * Method returns the stock, or in other words, the number of copies of this item currently in stock.
	 * @return An integer corresponding to the number of copies of this item currently in stock. 
	 */
	public int getStock() {
		return stock;
	}

	/**
	 * Method modifies the stock available for a toy object to the value passed to the function on call. 
	 * @param stock This is the new value for stock to be assigned to the instance toy object. 
	 */
	public void setStock(int stock) {
		this.stock = stock;
	}

	/**
	 * Method returns the suggested minimum age to use this item.
	 * @return Integer corresponding to the suggested minimum age to use this item.
	 */
	public int getMinAge() {
		return minAge;
	}

	/**
	 * Method modifies the suggested minimum age to use the toy to the value passed to this method. 
	 * @param minAge This is the new value for the suggested minimum age to use the toy.  
	 */
	public void setMinAge(int minAge) {
		this.minAge = minAge;
	}
	
	/**
	 * Method returns the type of toy category of the instance object. 
	 * @return String of the toy category of the toy object. 
	 */
	public String getCategory() {
		return category;
	}
	
	/**
	 * This method returns a string of the instance fields for a toy object formated appropriately for saving. 
	 * @return A string that encompasses all of the instance fields of a toy in a particular order, separated by semi-colons. 
	 */
	public String format() {
		return String.format("%s;%s;%s;%s;"
				+ "%s;%s;", this.serial, this.name,
				this.brand, this.price, this.stock, this.minAge);
	}
	
	/**
	 * This method evaluates the instance object to determine the type of toy category the instance variable is. It then returns a string of that category. 
	 * @return A string that refers to the type of toy category of the instance object is returned. 
	 */
	public String category() {
		String category=null;
		if (this instanceof Figure) {
			category = "Figure";
		}
		else if (this instanceof Puzzle) {
			category = "Puzzle";
		}
		else if (this instanceof Game) {
			category = "Board Game";
		}
		else if (this instanceof Animal) {
			category = "Animal";
		}
		return category;
	}
	
	/**
	 * This method is the toString, which returns a string of the object's fields that is in human readable form. 
	 * @return A string that encompasses all of the fields of the toy object after formating is returned. 
	 */
	public String toString() {
		return "Category:" +category+ " Serial Number: "+serial+ " Name: "+name+ " Brand: "+brand +" Price: "+price+" Available-Count:  "+stock+" Age-Appropriate: "+minAge;
	}
	
}
