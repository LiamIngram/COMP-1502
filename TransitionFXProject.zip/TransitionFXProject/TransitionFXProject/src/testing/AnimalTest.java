package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import model.Animal;

class AnimalTest {
	
	Animal a; 
	
	@BeforeEach
	void setUp() {
		a = new Animal("4084960372", "Sudoku","Game Shadow",264.27, 5, 6,"soft", 'L'); 
	}
	
	@Test
	void test_getMaterial_case1() {
		String expectedResult="soft";
		String actualResult= a.getMaterial();
		assertTrue(actualResult.equals(expectedResult));
	}
	
	@Test
	void test_setMaterial_case1() {
		String expectedResult="hard";
		a.setMaterial("hard");
		String actualResult= a.getMaterial();
		assertTrue(expectedResult.equals(actualResult));
	}
	
	@Test
	void test_getSize_case1() {
		char expectedResult='L';
		char actualResult= a.getSize();
		assertTrue(expectedResult==actualResult);
	}
	

}
