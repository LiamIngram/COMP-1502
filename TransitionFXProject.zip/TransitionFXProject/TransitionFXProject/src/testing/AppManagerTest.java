package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import controller.AppManager;

class AppManagerTest {
	
	AppManager am;

	@BeforeEach
	void setUp() throws Exception {
		am = new AppManager();
	}

	@Test
	void validateSN_test_case_1() {
		assertNull(am.validateSerialNumber("1234567890"));
	}
	
	@Test
	void validateSN_test_case_2() {
		assertNotNull(am.validateSerialNumber("ssssssssss"));
	}
	
	@Test
	void validateSN_test_case_3() {
		assertNotNull(am.validateSerialNumber("123456789"));
	}
	
	@Test
	void validateSN_test_case_4() {
		assertNotNull(am.validateSerialNumber("123456789/"));
	}


}
