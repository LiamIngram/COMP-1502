package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import model.Figure;

class FigureTest {

	Figure f;
	
	@BeforeEach
	void setUp() {
		f = new Figure("4084960372", "Sudoku","Game Shadow",264.27, 5, 6, 'A'); 
	}
	
	@Test
	void test_getType_case1() {
		char expected = 'A';
		char actual = f.getType();
		assertTrue(expected==actual);
	}
	
	@Test
	void test_setType_case1() {
		char expected = 'D';
		f.setType('D');
		char actual = f.getType();
		assertTrue(expected==actual);
	}

}
