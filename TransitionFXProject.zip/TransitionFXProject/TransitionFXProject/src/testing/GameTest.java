package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import model.Game;

class GameTest {

	Game g;
	
	@BeforeEach
	void setUp() {
		String[] designers = {"Tejas","James"};
		g = new Game("4084960372", "Sudoku","Game Shadow",264.27, 5, 6,3,5, designers); 
	}
	
	@Test
	void test_getPlayers_case1() {
		String expected = "3-5";
		String actual = g.getPlayers();
		assertTrue(expected.equals(actual));
	}
	
	@Test
	void test_getDesigners_case1() {
		String[] expected = {"Tejas","James"};
		String[] actual = g.getDesigners();
		
		for (int i=0; i<actual.length;i++) {
			assertTrue(actual[i].equals(expected[i]));
		}
	}
}
