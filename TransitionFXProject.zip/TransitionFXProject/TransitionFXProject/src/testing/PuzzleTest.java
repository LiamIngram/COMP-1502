package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import model.Game;
import model.Puzzle;

class PuzzleTest {

	Puzzle p;
	
	@BeforeEach 
	void setUp() {
		p = new Puzzle("4084960372", "Sudoku","Game Shadow",264.27, 5, 6, 'M'); 
		
	}
	
	@Test
	void test_getType_case1() {
		char expected = 'M';
		char actual = p.getType();
		assertEquals(expected,actual);
	}
	
	@Test
	void test_setType_case1() {
		char expected = 'C';
		p.setType('C');
		char actual = p.getType();
		assertTrue(expected==actual);
	}
	
}
